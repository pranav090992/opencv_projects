from .puzzle import find_puzzle
from .puzzle import extract_digit